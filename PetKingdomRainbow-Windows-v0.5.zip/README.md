# 宠物王国5：彩虹 — Godot 移植工程

Godot **4.6.3** / GDScript，目标为 Windows x64 与 Android arm64。

## 当前源码的实际范围

这一版将早期手写首段流程替换为原始数据和事件解释器。新游戏从原版地图 58、坐标 (9,16) 的序章开始。

- 68 张地图及门、碰撞、1,753 个场景对象配置。
- 409 个原始事件脚本、9,065 条可达指令；解释器覆盖数据中出现的 45 种指令。四处特殊分支结尾采用兼容修复，依据和局限见 RECOVERY_COMPATIBILITY.md。
- 1,981 条脚本对话与旁白；57 条主线、40 条支线文本。
- 102 种宠物、49 个技能、70 种道具的原始数据库。
- 146 套组合动画，包含人物、坐骑、宠物、表情与剧情特效。
- 伙伴、寄存、成长、技能卷轴、进化、孵化、背包、商店、宝箱、图鉴、任务与存档界面。
- 回合制战斗、捕获与四类小游戏：竞速、接球、记忆配对、杯子寻宠。
- 已接入主角、树怪、花系、仙人掌、果子小姐、铁甲士兵、铁头、螳螂、铜球兄弟、奇异兽及对应进化形态，以及蓝发女孩、蒙面人、白发老师、海豚、海豚骑乘和幽暗鬼王，共 17 套图集、252 个可见动画帧的高清像素重绘；其余图集继续使用原始资源。动画帧顺序、原始占地和镜像方向保持一致，审阅记录见 ART_REVIEW.md。
- 原始逐行显现与居中旁白已接入，保留时序，增加暗色背景和文字阴影；菜单使用不透明底色提高可读性。
- 地图前后景按空间分块筛选，仅绘制视野内摆件；9 首原 MIDI 乐曲转换为 OGG 循环播放。
- 内置字体只保留游戏用字，避免依赖设备是否安装中文字体。

**当前仍是开发版，不是完整复刻终版。** 已加入存档、药品、战斗、三种初始宠物分支、实际行走与剧情验证，以及全部地图和动画的渲染检查。验证报告位于 `build/verification/`。分段剧情验证覆盖序章、学院考试、东南西门试炼、追查猛虎、幽暗森林、北门救援、转校生、煌翼鸟救援、四门复赛、北海航线与初赛、旧校舍调查、安琪儿监狱救援、校长与幽暗鬼王战斗、核心实验室三处机关、普罗真相及最终章节告别（主线阶段 53）。本次完整构建的通过结果、检查数量和源码指纹以包内验证记录为准。幽暗森林最终战、冠军赛、全部支线、Windows／Android 实机试玩、全部高清重绘和设备性能测量尚未完成。

修复包括读档后的技能编号类型、地图切换后的事件标记、对话和过场控制、坐骑地形、NPC 面向交互、商人寄存服务、相邻宝箱选择和无库存道具的使用。v0.4 恢复原版每场战斗开始时清除异常状态的行为，并在换宠时即时登记经验参与者。v0.5 修复墙砖门口的进入判断，加入原作战斗商店的 20% 加价购买与忠诚度为零时的攻击限制，并恢复行动后持续伤害、回血与状态扣减的顺序，以及首领额外技能槽。关闭窗口时先释放背景音乐并等待音频帧回收，避免剧情中退出残留 OGG 播放资源。

## 下载与操作

v0.5 开发构建通过验证后生成在以下路径；这些是工作区文件路径，并非公开下载网址：

- build/distribution/PetKingdomRainbow-Windows-v0.5.zip：Windows 64 位，解压后双击 EXE 启动。
- build/android/PetKingdomRainbow-v0.5.apk：Android 7.0 及以上、arm64 调试 APK，下载后允许对应下载应用安装，再安装运行。
- build/distribution/PetKingdomRainbow-v0.5.zip：Windows、Android、源码、反编译资料、测试报告与版本说明集合。
- build/distribution/PetKingdomRainbow-verification-v0.5.zip：自动验证、截图、APK 签名与对齐检查记录。

v0.1、v0.2、v0.3、v0.4 历史构建仍保留，内容与当前版本不同。v0.3 未包含战斗开始清除异常状态的修复。

WASD／方向键移动，E／Enter 交互和继续对话，J 打开任务，Esc 打开菜单。触屏使用左下方向按钮、右下交互按钮与顶部菜单。剧情过场期间按“继续”或 E 推进对话。

存档：user://rainbow_full_save.json，版本 2。早期 v0.1 的手写流程存档格式不同，不会自动迁移。

## 复现构建

普通桌面开发使用 Godot 4.6.3 打开 project.godot 并安装同版本导出模板。Windows 导出使用内置 x64 模板。Android 当前使用预编译模板和 SDK Build Tools 35.0.0 签名，不使用 Gradle 构建，也不需要为这个导出流程下载 NDK。

云工作区安装与构建：

~~~sh
cd /workspace/putty-pro-shi
bash reverse-engineering/recaf4/install_recaf.sh
python3 godot-port/tools/setup_cloud.py
python3 godot-port/tools/setup_wine_checks.py
bash godot-port/tools/verify_rendered.sh
bash godot-port/tools/build.sh
python3 godot-port/tools/package_release.py
~~~

SDK、Godot、模板、JDK 和 Wine 保存在 /workspace/.tools、/workspace/.local/share；不修改 HOME 或系统 Java。Godot 和模板使用官方 SHA-512，Android 包使用官方仓库清单中的 SHA-1 校验值。Wine 10 使用经 Debian 签名仓库索引核对的固定 SHA-256 包，只调整工作区启动路径。

当前 APK 用开发签名，供直接安装试玩；正式发布仍需发行签名和发布设置。云实例的 ADB 37 在只读用户目录下无法创建 .android，因此设备发现不可用；导出、对齐、签名与 APK 检查已完成。此环境没有 Android 模拟器。

构建脚本额外通过 Wine 执行实际 Windows EXE，检查无窗口启动、窗口渲染、游戏菜单、新游戏鼠标输入和正常窗口关闭，并将程序和截图 SHA-256 写入导出记录。该检查使用 Linux 软件渲染和 Windows 兼容层，不代表真实 Windows 通关或设备性能。工作区中的 Wine 测试前缀与玩家存档分开。

## 源码与数据工具

执行验证：

~~~sh
bash godot-port/tools/verify.sh
bash godot-port/tools/verify_rendered.sh
~~~

从仓库根目录执行。测试使用独立存档和配置目录。渲染检查使用工作区内安装并校验 SHA-256 的 Xvfb，不依赖物理 GPU，也不代表手机或 Windows 实机性能。

- scripts/game.gd：主界面、世界绘制、交互与导航。
- scripts/story_vm.gd：原始剧情事件执行。
- scripts/narration.gd：逐行显现与居中旁白。
- scripts/game_state.gd：数据库、宠物及存档状态。
- scripts/sprite_renderer.gd：原始模块／帧／动画组合与变换。
- scripts/battle.gd：宠物战斗。
- scripts/pet_services.gd：进化、孵化、卷轴学习。
- scripts/mini_games.gd：四类小游戏。
- scripts/main.gd：仅保留早期手写原型，不是当前主场景入口。
- tools/extract_game_data.py：提取数据库、NPC、门、宝箱、事件和动画。
- tools/extract_maps.py、tools/extract_missions.py：提取地图和任务文本。
- tools/render_music.py：FluidSynth／ffmpeg 转换原乐曲。
- tools/subset_ui_font.py：生成中文 UI 字体子集。
- tools/audit_progression.py：索引 57 条主线、40 条支线对应的原始事件、条件和首领等级，并读取指定存档的任务标记；静态索引不代表任务已经通关。
- tools/verify_windows_wine.py：执行 Windows EXE，点击新游戏并关闭窗口，捕获菜单和序章；通过特定界面颜色区分引擎启动画面与已加载的游戏界面。

事件解释器使用根目录的 4 与 event，它们是原引擎实际加载的版本；data/4、data/event 中的旧副本不用于替代。

验证分为固定状态的系统用例与实际操作的剧情用例。regression.gd 和 mini_games.gd 使用系统测试状态；navigation.gd 至 core_revelation.gd 的剧情用例使用实际移动、NPC 对话和界面按钮，后续段读取前一段成功后生成的存档，不直接注入任务、道具或战斗结果。记忆游戏补给路线只在预览时读取显示出来的牌名，不读取隐藏牌面。训练通过原始随机遇敌获得等级和技能，实际购买药品和回复伙伴，不修改战斗伤害或保证胜利。旧校舍的等级 70 对手按原脚本发生败战后继续剧情；普通首领战必须获胜。渲染截图是专门的显示测试场景，不是全剧情通关证据。

验证和构建记录保存游戏、数据、美术与测试的源码指纹。构建与打包必须匹配当前通过的验证；每个安装包另记文件长度和 SHA-256。APK 验证开发签名与 16 KB 原生库对齐。生成新构建不会覆盖旧版本记录。

用户指定的 REA 是 [morluto/rea](https://github.com/morluto/rea)。实际静态 JAR 检查记录在父目录 reverse-engineering/rea/；Java 恢复使用 Recaf 的 CFR／Vineflower 结果。反编译文本不是开发者原始源码。
