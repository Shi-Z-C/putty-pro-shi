# 资源与授权来源

- `assets/original/` 中的资源来自用户提供的 `宠物王国5 彩虹_n97.jar`，保留原始文件；编译后的 `.class` 文件没有复制进 Godot 工程。
- `assets/remastered/`：按 Godot 渲染出的原始完整帧参考，通过图像生成工具重新绘制高清像素素材。`sprites.json` 保存图片 SHA-256、裁切区域、原始占地与锚点。图片保持生成文件的字节内容，注册工具仅分析透明度并生成元数据。目前仅部分角色和宠物完成接入；姿态或帧顺序有误的稿件未接入游戏。
- 用户确认持有改编授权，并表示会提供源码与素材；目前用于工程的实际输入仍是该 JAR 与 CFR 反编译压缩包。
- `data/main_quests.json` 与 `data/side_quests.json` 是从 JAR 中的任务文本表解码生成；`data/maps/maps.json` 由原地图包装文件与 `.mid` 图层数据转换。
- 反编译工具：CFR 0.152（MIT）与 Vineflower 1.12.0（Apache-2.0）；其输出留在父目录作为分析资料。
- 进一步使用 Recaf 4 的 CFR 0.152、Vineflower 1.11.2 输出进行数据结构恢复；REA `rea-agents@6.3.0`（MIT）用于静态包清单。
- `assets/audio/`：原 `music/0.mid` 至 `8.mid` 经 FluidSynth、系统 TimGM6mb 音色库渲染，再用 ffmpeg 编码为 OGG。旋律数据来自原游戏，音色与原 Nokia 设备可能不同。音色库不随包分发；TimGM6mb 由 Tim Brechbill、David Bolton 制作，系统包声明 GPL-2。
- `assets/fonts/RainbowSans-Regular.otf`：系统 Noto Sans CJK SC 字体的游戏用字子集，已改名为 Rainbow Sans。原字体采用 SIL Open Font License 1.1，完整版权与许可保存在同目录 `LICENSE.txt`；字体处理工具为 fontTools。
